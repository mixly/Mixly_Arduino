Mixly 帮助文档
=====================

欢迎您，使用Mixly！

软件使用基础
---------------------------------------
.. toctree::
   :maxdepth: 2

   zh/basic/index.rst

Arduino 编程
---------------------
.. toctree::
   :maxdepth: 2

   zh/arduino/index.rst

Python 编程
-----------------------
.. toctree::
   :maxdepth: 2

   zh/Python/index.rst

MicroPython 编程
---------------------------
.. toctree::
   :maxdepth: 2

   zh/MicroPython/index.rst
