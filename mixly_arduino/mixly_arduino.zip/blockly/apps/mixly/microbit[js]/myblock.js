var myblock='null';
var company_block='null';
